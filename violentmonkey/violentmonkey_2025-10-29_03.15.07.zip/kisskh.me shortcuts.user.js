// ==UserScript==
// @name        kisskh.me shortcuts
// @namespace   CoderOM
// @match       https://kisskh.*/*
// @grant       none
// @version     1.0
// @author      CoderOM
// @description 12/10/2022, 4:54:14 PM
// ==/UserScript==


(function () {
    "use strict";
    let isHidden = false;
    // https://kisskh.*/Drama/*
    // Deregister any existing spacebar event listener by capturing phase
    window.addEventListener("keydown", function (e) {
        if (e.key === " ") {
            e.preventDefault(); // Prevent default action for spacebar
            e.stopImmediatePropagation(); // Stop other listeners for this event
        }
    }, true); // Capture phase to ensure it overrides other handlers

    // Register your custom event handler
    document.addEventListener("keydown", function (e) {
        if (e.key === " ") {
            // Custom functionality for the spacebar
            document.getElementsByClassName("video")[0].click();
        }
        if (e.key.toLowerCase() === 'f') {
            // Custom functionality for 'F' key
            document.querySelector('mat-fullscreen-button').children[0].click();
        }
        if (e.key.toLowerCase() === "g") {
            // Custom functionality for 'G' key
            const controls = document.getElementsByClassName("controls ng-star-inserted visible")[0];
            const video = document.querySelector('mat-video').children[0].children[1];

            if (isHidden) {
                controls.style.visibility = 'visible';
                video.style.visibility = 'visible';
                isHidden = false;
            } else {
                controls.style.visibility = 'hidden';
                video.style.visibility = 'hidden';
                isHidden = true;
            }
        }
    });
})();

