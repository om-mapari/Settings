// ==UserScript==
// @name         Hide/Show Video Progress Bar and Controller
// @namespace   CoderOM
// @match       file:///C:/*
// @match       file:///D:/*
// @grant       none
// @version     1.0
// @author      CoderOM
// @description  Press "G" to toggle the visibility of the video progress bar and controller.
// ==/UserScript==


(function() {
    // Get the video element
    var video = document.querySelector('video');

    // Create a style element to hide the progress bar and controller
    var style = document.createElement('style');
    style.innerHTML = `
        .vsc-controller,
        video::-webkit-media-controls-panel {
            display: none !important;
        }
    `;

    // Add the style element to the document head
    // document.head.appendChild(style);

    // Function to toggle the visibility of the progress bar and controller
    function toggleProgressBarAndController() {
        if (video.hasAttribute('controls')) {
            video.removeAttribute('controls');
        } else {
            video.setAttribute('controls', 'controls');
        }
    }

    // Listen for keydown events
    document.addEventListener('keydown', function(event) {
      console.log("toggle")
        // Check if the "G" key was pressed
        if (event.key === 'g' || event.key === 'G') {
            toggleProgressBarAndController();
        }
    });



    document.addEventListener("keydown", function onEvent(e) {
        if (e.key.toLowerCase() === "f") {
            if (document.fullscreenElement == null) {
                document.querySelector("video").requestFullscreen();
            } else {
                document.exitFullscreen();
            }
        }
    });

})();
