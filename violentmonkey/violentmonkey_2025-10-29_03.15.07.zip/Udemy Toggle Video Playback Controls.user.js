// ==UserScript==
// @name         Udemy Toggle Video Playback Controls
// @namespace    https://github.com/
// @version      2025-02-11
// @description  Toggle Playback Controls by pressing "G"
// @author       CoderOM
// @match        https://www.udemy.com/course/*
// @icon         https://www.udemy.com/staticx/udemy/images/v7/apple-touch-icon.png
// @license      MIT
// @grant        none
// ==/UserScript==
(function () {
  "use strict";

  let isHidden = false; // Track the state

  window.addEventListener("keydown", (event) => {
    console.log(event.key.toLowerCase())
    if (event.key.toLowerCase() === "g") { // Press "G" to toggle
      const controls = document.querySelector(
        ".shaka-control-bar--control-bar-container--OfnMI"
      );
      const nextAndPrevious = document.querySelectorAll(
        ".next-and-previous--container--kZxyo"
      );
      const headerGradient = document.querySelector(
        ".video-viewer--header-gradient--x4Zw0"
      );
      const headerTitle = document.querySelector(
        ".video-viewer--title-overlay--YZQuH"
      );

      if (controls || headerGradient || headerTitle) {
        isHidden = !isHidden; // Toggle state

        // Apply styles based on the toggle state
        const visibility = isHidden ? "0" : "1";
        const display = isHidden ? "none" : "block";

        controls.style.opacity = visibility;
        nextAndPrevious.forEach((element) => (element.style.opacity = visibility));
        headerGradient.style.display = display;
        headerTitle.style.display = display;
      }
    }
  });
})();





// (function () {
//   "use strict";
//   window.addEventListener("keydown", (event) => {
//     const controls = document.querySelector(
//       ".shaka-control-bar--control-bar-container--OfnMI"
//     );
//     const nextAndPrevious = document.querySelectorAll(
//       ".next-and-previous--container--kZxyo"
//     );
//     const headerGradient = document.querySelector(
//       ".video-viewer--header-gradient--x4Zw0"
//     );
//     const headerTitle = document.querySelector(
//       ".video-viewer--title-overlay--YZQuH"
//     );
//     if (event.key === "h" && event.altKey) {
//       controls.setAttribute("style", "opacity: 0 !important");
//       nextAndPrevious.forEach((element) => {
//         element.setAttribute("style", "opacity: 0 !important");
//       });
//       headerGradient.setAttribute("style", "display: none !important");
//       headerTitle.setAttribute("style", "display: none !important");
//     } else if (event.key === "d" && event.altKey) {
//       controls.setAttribute("style", "opacity: 1 !important");
//       nextAndPrevious.forEach((element) => {
//         element.setAttribute("style", "opacity: 1 !important");
//       });
//       headerGradient.setAttribute("style", "display: block !important");
//       headerTitle.setAttribute("style", "display: block !important");
//     }
//   });
// })();
