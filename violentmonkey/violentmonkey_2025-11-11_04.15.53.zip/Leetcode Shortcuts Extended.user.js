// ==UserScript==
// @name        Leetcode Shortcuts Extended
// @namespace   CoderOM
// @match       https://leetcode.com/problems/*/
// @grant       none
// @version     1.0
// @author      CoderOM
// @description 12/13/2022, 9:59:13 PM
// ==/UserScript==


(function () {
  ("use strict");
  let NewdoubleClickEvent = document.createEvent("MouseEvents");
  NewdoubleClickEvent.initEvent("dblclick", true, true);
  let open = true;
  // let middleBar = document.getElementsByClassName("group flex h-full items-center justify-center transition hover:bg-blue-s dark:hover:bg-dark-blue-s w-2 hover:cursor-col-resize")[0];
  // document.getElementsByClassName("ml-1 transform transition")[0].click();
  console.log("UserScript Running")
  setTimeout(()=>{
        document.querySelector("nav").style.display = "none";
  },3000)
  window.addEventListener("keydown", function onEvent(e) {
      if (e.key.toLowerCase() === "o" && e.ctrlKey) {
          e.preventDefault();
          if (open) {
            let middleBar = document.getElementsByClassName("group flex h-full items-center justify-center transition hover:bg-blue-s dark:hover:bg-dark-blue-s w-2 hover:cursor-col-resize")[0];
            middleBar.dispatchEvent(NewdoubleClickEvent);
              open = false;
          } else {
              document.getElementsByClassName("flex h-full flex-col justify-around text-3xl")[0].click();
              open = true;
          }
      }

      if (e.key === ";" && e.ctrlKey) document.getElementsByClassName("ml-1 transform transition")[0].click();

      if (e.key.toLowerCase() === "f" && e.ctrlKey) {
          e.preventDefault()
          if (!focus) {
              document.querySelector("nav").style.display = "none";
              focus = true;
          } else {
              document.querySelector("nav").style.display = "";
              focus = false;
          }
      }

      if (e.key.toLowerCase() === "m" && e.ctrlKey) {
        console.log('hi')
        e.preventDefault();
        document.getElementsByClassName("rounded px-3 py-1.5 font-medium items-center whitespace-nowrap transition-all focus:outline-none inline-flex hover:bg-fill-3 dark:hover:bg-dark-fill-3 ml-auto !p-1")[4].click()
      }

  });
})();