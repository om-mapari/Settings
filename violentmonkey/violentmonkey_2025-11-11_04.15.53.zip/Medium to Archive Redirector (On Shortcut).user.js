// ==UserScript==
// @name         Medium to Archive Redirector (On Shortcut)
// @namespace    https://omdevs.dev
// @version      1.1
// @description  Redirects any Medium article to its archived version on archive.md using Ctrl+Shift+A
// @author       CoderOM
// @match        *://*.medium.com/*
// @grant        none
// @run-at       document-start
// ==/UserScript==

(function () {
    'use strict';

    document.addEventListener('keydown', function (e) {
        // Check for Ctrl + Shift + A
        if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 'f') {
            const originalURL = window.location.href;

            // Prevent redirect loop
            if (!originalURL.startsWith("https://archive.md/")) {
                const archiveURL = `https://archive.md/${originalURL}`;
                window.location.replace(archiveURL);
            }
        }
    });
})();
