// ==UserScript==
// @name         FKM - Order ID + Dispute Steps (Premium UI)
// @namespace    http://tampermonkey.net/
// @version      3.5
// @description  Beautiful UX enhancement for Cashback History + Steps Table
// @match        https://m.freekaamaal.com/cashback/cashback-history
// @grant        GM_xmlhttpRequest
// @connect      fkmapiservice.freekaamaal.com
// @run-at       document-idle
// ==/UserScript==

(function() {
    "use strict";

    const API_HISTORY = "https://fkmapiservice.freekaamaal.com/cashback/cashback-history";
    const API_TRYOUT = "https://fkmapiservice.freekaamaal.com/tryout/raisedispute";

    /* ============================================================
       PREMIUM UX CSS
    ============================================================ */
    (function addStepTableCSS() {
        const css = `
        /* Container box around the table */
        .fkm-table-wrapper {
            margin-top: 15px;
            padding: 18px;
            background: #ffffff;
            border-radius: 15px;
            border: 1px solid #e6e6e6;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            width: 92%;
            margin-left: auto;
            margin-right: auto;
            animation: fkmSlideIn 0.25s ease-out;
        }

        @keyframes fkmSlideIn {
            from { transform: translateY(8px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .fkm-steps-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            font-size: 13px;
        }

        .fkm-steps-table th {
            padding: 10px;
            background: #eef4ff;
            color: #2c3e50;
            font-weight: 600;
            border-bottom: 1px solid #d0d7e3;
            text-align: left;
        }

        .fkm-steps-table td {
            padding: 10px;
            border-bottom: 1px solid #f3f3f3;
        }

        .fkm-steps-table tr:last-child td {
            border-bottom: none;
        }

        /* Status badges */
        .fkm-status-completed,
        .fkm-status-approved {
            background: #e7f7ec !important;
            color: #1e8f4e !important;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 10px;
            display: inline-block;
            text-transform: capitalize;
        }

        .fkm-status-current {
            background: #fff4e0;
            color: #d67b1b;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 10px;
            display: inline-block;
            text-transform: capitalize;
        }

        .fkm-status-pending {
            background: #ededed;
            color: #6d6d6d;
            font-weight: 600;
            padding: 6px 12px;
            border-radius: 10px;
            display: inline-block;
            text-transform: capitalize;
        }
        `;
        const style = document.createElement("style");
        style.innerHTML = css;
        document.head.appendChild(style);
    })();

    /* ============================================================
       Helper Functions
    ============================================================ */
    function getCookie(name) {
        const value = `; ${document.cookie}`;
        const parts = value.split(`; ${name}=`);
        if (parts.length === 2) return decodeURIComponent(parts.pop().split(";")[0]);
        return null;
    }

    function shouldRun() {
        const path = location.pathname;
        return path.includes("/cashback-history");
    }

    /* ============================================================
       Fetch Cashback List
    ============================================================ */
    function fetchCashbacks(callback) {
        const authToken = getCookie("userToken");
        if (!authToken) return;

        GM_xmlhttpRequest({
            method: "POST",
            url: API_HISTORY,
            headers: {
                "Content-Type": "application/json",
                "authorization": authToken
            },
            data: JSON.stringify({
                apiAuth: "fkm22",
                device_type: "2",
                option: "pending",
                page: 1
            }),
            onload: (res) => {
                const json = JSON.parse(res.responseText || "{}");
                callback(json?.response?.transaction || []);
            }
        });
    }

    /* ============================================================
       Fetch Steps
    ============================================================ */
    function fetchSteps(clickId, callback) {
        const authToken = getCookie("userToken");
        if (!authToken) return;

        GM_xmlhttpRequest({
            method: "POST",
            url: API_TRYOUT,
            headers: {
                "Content-Type": "application/json",
                "authorization": authToken
            },
            data: JSON.stringify({
                apiAuth: "fkm22",
                device_type: "1",
                click_id: clickId
            }),
            onload: (res) => {
                try {
                    const json = JSON.parse(res.responseText || "{}");
                    callback(json?.response?.steps || []);
                } catch {
                    callback([]);
                }
            }
        });
    }

    /* ============================================================
       Inject Beautiful Table
    ============================================================ */
    function injectTable(card, steps) {
        if (!steps.length) return;
        if (card.querySelector(".fkm-table-wrapper")) return;

        const wrapper = document.createElement("div");
        wrapper.className = "fkm-table-wrapper";

        const table = document.createElement("table");
        table.className = "fkm-steps-table";

        table.innerHTML = `
            <tr>
                <th>#</th>
                <th>Step</th>
                <th>Status</th>
            </tr>
        `;

        steps.forEach((s, i) => {
            table.innerHTML += `
                <tr>
                    <td>${i + 1}</td>
                    <td>${s.title}</td>
                    <td class="fkm-status-${s.status.toLowerCase()}">${s.status}</td>
                </tr>
            `;
        });

        wrapper.appendChild(table);
        card.appendChild(wrapper);
    }

    /* ============================================================
       Main Page Handler
    ============================================================ */
    function processPage() {
        if (!shouldRun()) return;

        const cards = document.querySelectorAll(".cashback_history_card");
        if (!cards.length) return;

        fetchCashbacks((list) => {
            cards.forEach((card) => {
                const txId = card.querySelector("p")?.innerText?.trim();
                if (!txId) return;

                const info = list.find(t => String(t.id) === String(txId));
                if (!info) return;

                /* ---- ORDER ID ---- */
                if (!card.querySelector(".fkm-order-id")) {
                    const el = document.createElement("div");
                    el.className = "fkm-order-id";
                    el.style.fontSize = "13px";
                    el.style.marginTop = "6px";
                    el.style.fontWeight = "600";
                    el.innerHTML = `<b>Order ID:</b> ${info.orderid}`;
                    card.querySelector(".cashback_history_card_first_child").appendChild(el);
                }

                /* ---- STEPS ---- */
                fetchSteps(info.id, (steps) => {
                    injectTable(card, steps);
                });
            });
        });
    }

    /* ============================================================
       Observer for SPA updates
    ============================================================ */
    const observer = new MutationObserver(() => {
        if (shouldRun()) setTimeout(processPage, 300);
    });

    observer.observe(document.body, { childList: true, subtree: true });

    setTimeout(processPage, 600);

})();
