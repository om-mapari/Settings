// ==UserScript==
// @name         YouTube - hide player controls
// @namespace    http://www.xyz.net/
// @license      WTFPL; http://www.xyz.net/
// @version      0.3
// @description  Add shortcut in YouTube video player controls for hiding/showing controls. (press g to hide)
// @author       CoderOm
// @include      https://www.youtube.com/*
// ==/UserScript==

(function () {
    "use strict";
    let isHidden = false;

    document.addEventListener("keydown", function (e) {
        if (e.key.toLowerCase() === "g") {
            if (isHidden) {
                // Show elements
                toggleVisibilityByClass('ytp-chrome-top', 'visible');
                toggleVisibilityByClass('ytp-chrome-bottom', 'visible');
                toggleVisibilityByClass('ytp-gradient-bottom', 'visible');
                toggleVisibilityByClass('ytp-gradient-top', 'visible');
                toggleVisibilityByClass('ytp-overlay-top-left', 'visible');
                toggleVisibilityByClass('ytp-overlay-bottom-left', 'visible');
                toggleVisibilityByClass('ytp-overlay-bottom-right', 'visible');
                toggleVisibilityByClass('ytp-overlays-container', 'visible');
                toggleVisibilityByClass('branding-img-container', 'visible');
                toggleVisibilityByClass('ytPlayerOverlayVideoDetailsRendererHost', 'visible');
                toggleVisibilityByClass('ytp-overlay-top-right', 'visible');
                toggleVisibilityByClass('ytp-suggested-action', 'visible');

                // NEW → Fullscreen More Videos button
                toggleVisibilityByClass('ytp-fullscreen-grid-expand-button', 'visible');

                isHidden = false;
            } else {
                // Hide elements
                toggleVisibilityByClass('ytp-chrome-top', 'hidden');
                toggleVisibilityByClass('ytp-chrome-bottom', 'hidden');
                toggleVisibilityByClass('ytp-gradient-bottom', 'hidden');
                toggleVisibilityByClass('ytp-gradient-top', 'hidden');
                toggleVisibilityByClass('ytp-overlay-top-left', 'hidden');
                toggleVisibilityByClass('ytp-overlay-bottom-left', 'hidden');
                toggleVisibilityByClass('ytp-overlay-bottom-right', 'hidden');
                toggleVisibilityByClass('ytp-overlays-container', 'hidden');
                toggleVisibilityByClass('branding-img-container', 'hidden');
                toggleVisibilityByClass('ytPlayerOverlayVideoDetailsRendererHost', 'hidden');
                toggleVisibilityByClass('ytp-overlay-top-right', 'hidden');
                toggleVisibilityByClass('ytp-suggested-action', 'hidden');

                // NEW → Fullscreen More Videos button
                toggleVisibilityByClass('ytp-fullscreen-grid-expand-button', 'hidden');

                isHidden = true;
            }
        }
    });

    function toggleVisibilityByClass(className, visibility) {
        const elements = document.getElementsByClassName(className);
        if (elements.length > 0) {
            Array.from(elements).forEach((el) => {
                el.style.visibility = visibility;
                const children = el.querySelectorAll('*');
                children.forEach((child) => {
                    child.style.visibility = visibility;
                });
            });
        }
    }
})();
