// ==UserScript==
// @name         Google Dark Mode Snippet Contrast Fix
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Improve visibility of dim/low-contrast snippet text in Google dark mode search results.
// @match       https://www.google.com/search*
// @author      CoderOM
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    const style = document.createElement('style');

    style.textContent = `
        /* Make snippet text brighter */
        .VwiC3b, .VwiC3b span {
            color: #e8e8e8 !important;
        }

        /* Underline ONLY the emphasized part */
        .VwiC3b em {
            color: #ffffff !important;
            font-style: normal !important;
            font-weight: 600 !important;
            text-decoration: underline !important;
            text-underline-offset: 3px !important;
        }

        /* Optional: Increase snippet font slightly for readability */
        .VwiC3b {
            font-size: 15px !important;
            line-height: 1.45 !important;
        }
    `;

    document.head.appendChild(style);
})();


