// ==UserScript==
// @name         Video Element Injector
// @namespace    video-injector
// @version      1
// @description  Inject a small video element on any website that can be moved around the screen with a mouse press.
// @match        https://www.elitmus.com/
// @grant        none
// ==/UserScript==

(function() {
  'use strict';

  // Create the video container and video elements
  const videoContainer = document.createElement('div');
  videoContainer.id = 'video-container';
  videoContainer.style.position = 'fixed';
  videoContainer.style.top = '20px';
  videoContainer.style.right = '20px';
  videoContainer.style.width = '400px';
  videoContainer.style.height = '200px';
  videoContainer.style.overflow = 'hidden';

  const video = document.createElement('video');
  video.id = 'video';
  video.src = 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4';
  video.style.display = 'block';
  video.style.width = '100%';
  video.style.height = '100%';

  videoContainer.appendChild(video);
  document.body.appendChild(videoContainer);

  video.play();

  // Add event listeners to the video element for dragging
  let isDragging = false;
  let dragStartX;
  let dragStartY;

  video.addEventListener('mousedown', dragStart);
  video.addEventListener('mouseup', dragEnd);
  video.addEventListener('mousemove', drag);

  function dragStart(event) {
    isDragging = true;
    dragStartX = event.clientX - videoContainer.offsetLeft;
    dragStartY = event.clientY - videoContainer.offsetTop;
  }

  function dragEnd() {
    isDragging = false;
  }

  function drag(event) {
    if (isDragging) {
      event.preventDefault();

      const dragX = event.clientX - dragStartX;
      const dragY = event.clientY - dragStartY;

      const maxX = window.innerWidth - videoContainer.offsetWidth;
      const maxY = window.innerHeight - videoContainer.offsetHeight;

      const newX = Math.max(0, Math.min(maxX, dragX));
      const newY = Math.max(0, Math.min(maxY, dragY));

      videoContainer.style.left = newX + 'px';
      videoContainer.style.top = newY + 'px';
    }
  }
})();
