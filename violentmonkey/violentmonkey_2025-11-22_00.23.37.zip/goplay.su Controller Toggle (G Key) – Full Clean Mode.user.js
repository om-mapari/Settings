// ==UserScript==
// @name        goplay.su Controller Toggle (G Key) – Full Clean Mode
// @namespace   CoderOM
// @match       https://goplay.su/*
// @grant       none
// @version     1.1
// @author      CoderOM
// @description Fully hide JWPlayer UI + gradient shadow using G
// ==/UserScript==

(function () {
    "use strict";

    let isHidden = false;

    function waitForPlayer(cb) {
        const iv = setInterval(() => {
            const player = document.querySelector('.jwplayer');
            if (player) {
                clearInterval(iv);
                cb(player);
            }
        }, 250);
    }

    waitForPlayer((player) => {
        document.addEventListener("keydown", function (e) {
            if (e.key.toLowerCase() !== "g") return;

            e.preventDefault();

            if (!isHidden) {
                // Hide ALL important UI elements
                const style = document.createElement("style");
                style.id = "jw-hide-ui";
                style.innerHTML = `
                    .jw-controlbar,
                    .jw-dock,
                    .jw-tooltip,
                    .jw-shelf,
                    .jw-slider-time,
                    .jw-knob,
                    .jw-rail,
                    .jw-buffer,
                    .jw-progress,
                    .jw-controls,
                    .jw-controlbar-container,
                    .jw-text-elapsed,
                    .jw-text-duration,
                    .jw-text-countdown,
                    .jw-bottom-bar,
                    .jw-video-overlay,
                    .jwplayer .jw-controls-backdrop,
                    .jwplayer .jw-gradient,
                    .jwplayer .jw-display,
                    .jwplayer .jw-nextup,
                    .jwplayer .jw-button-container {
                        display: none !important;
                        opacity: 0 !important;
                        visibility: hidden !important;
                    }

                    /* Remove the shadow under the progress bar */
                    .jw-slider-time::before,
                    .jw-controlbar::before,
                    .jw-controlbar::after,
                    .jwplayer::after,
                    .jwplayer::before {
                        display: none !important;
                        background: none !important;
                        box-shadow: none !important;
                    }

                    /* Remove background blur/gradient */
                    .jw-controlbar,
                    .jw-controlbar-container {
                        background: transparent !important;
                        box-shadow: none !important;
                    }
                `;
                document.head.appendChild(style);

                player.style.cursor = "none";
                isHidden = true;
            } else {
                // Restore all UI
                const old = document.getElementById("jw-hide-ui");
                if (old) old.remove();
                player.style.cursor = "default";
                isHidden = false;
            }
        });
    });

})();
