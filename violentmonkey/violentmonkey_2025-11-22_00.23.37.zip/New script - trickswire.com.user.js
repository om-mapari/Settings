// ==UserScript==
// @name        New script - trickswire.com
// @namespace   CoderOM
// @match       https://trickswire.com/*
// @grant       none
// @version     1.0
// @author      CoderOM
// @description 12/17/2022, 9:41:49 PM
// ==/UserScript==


(function () {
    "use strict";
    let isHidden = false;
    document.addEventListener("keydown", function onEvent(e) {
        if(e.key.toLowerCase() === 'f'){
            const str = document.getElementsByClassName('wp-block-preformatted')[0].innerText
            const el = document.createElement('textarea');
            el.value = str;	//str is your string to copy
            document.body.appendChild(el);
            el.select();
            document.execCommand('copy');	// Copy command
            document.body.removeChild(el);
        }

    });
})();
