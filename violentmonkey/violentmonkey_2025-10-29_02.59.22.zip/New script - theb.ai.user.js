// ==UserScript==
// @name        New script - theb.ai
// @namespace   CoderOM
// @match       https://chat.theb.ai/
// @grant       none
// @version     1.0
// @author      CoderOM
// @description 3/15/2023, 9:58:49 AM
// @grant         GM_addStyle
// ==/UserScript==

// Get the textarea element
const textareaEl = document.querySelector('.n-input__textarea-el');

// Set the rows attribute to a larger value
textareaEl.rows = 6;

// Set the height of the textarea element to accommodate the larger size
textareaEl.style.height = '120px';

// (()=>{
//   setInterval(()=>{
//     if(document.querySelector('.flash-cards-block.show')){

//       document.querySelector('.flash-cards-close').click()
//       console.log('click')
//     }
//   },1000)

// })()


// const textarea = document.querySelector('.n-input__textarea-el');

// // Increase the number of rows on click
// textarea.addEventListener('click', () => {
//   // Set the new number of rows
//   console.log(textarea.rows);
//   const numRows = 8;
//   textarea.rows = numRows;
// });