// ==UserScript==
// @name        viki shortcuts
// @namespace   CoderOM
// @match       https://www.viki.com/videos/*
// @grant       none
// @version     1.0
// @author      CoderOM
// @description 12/12/2022, 8:46:39 PM
// ==/UserScript==


(function () {
    "use strict";
    let isHidden = false;
    document.addEventListener("keydown", function onEvent(e) {
        // if(e.key.toLowerCase() === 'f'){
        //   document.querySelector('mat-fullscreen-button').children[0].click()
        // }
        // if (e.key === " ") {
        //     document.querySelector('mat-play-button').children[0].click()
        // }
        if (e.key.toLowerCase() === "g") {
            if (isHidden) {

document.getElementsByClassName('vkp-timed-comments-overlay-actions')[0].style.visibility = 'visible'
document.getElementsByClassName("vjs-control-bar")[0].style.visibility = 'visible'
document.getElementsByClassName("vkp-container-link")[0].style.visibility = 'visible'
                isHidden = false;
            } else {
document.getElementsByClassName('vkp-timed-comments-overlay-actions')[0].style.visibility = 'hidden'
document.getElementsByClassName("vjs-control-bar")[0].style.visibility = 'hidden'
document.getElementsByClassName("vkp-container-link")[0].style.visibility = 'hidden'
                isHidden = true;
            }
        }
    });
})();
