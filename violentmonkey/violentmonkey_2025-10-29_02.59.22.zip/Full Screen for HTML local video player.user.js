// ==UserScript==
// @name         Full Screen for HTML local video player
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Use F key for Full screen Toggle
// @author       CoderOm
// @match        file:///D:/*
// @icon
// @grant        none
// ==/UserScript==
(function () {
    "use strict";
    //alert('hi')

    document.addEventListener("keydown", function onEvent(e) {
        if(e.key.toLowerCase()==='f'){
            if (document.fullscreenElement == null) {
                document.querySelector('video').requestFullscreen()
              } else {
                document.exitFullscreen()
            }
        }
    });

  var video = document.querySelector("video");
  var controlsHidden = false;

  document.addEventListener("keydown", function(event) {
    if (event.keyCode === 71) { // 'g' key
      if (controlsHidden) {
        video.setAttribute("controls", "true");
        controlsHidden = false;
      } else {
        video.removeAttribute("controls");
        controlsHidden = true;
      }
    }
  });

})();