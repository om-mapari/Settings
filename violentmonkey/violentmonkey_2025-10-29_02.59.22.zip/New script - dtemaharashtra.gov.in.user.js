// ==UserScript==
// @name        New script - dtemaharashtra.gov.in
// @namespace   CoderOM
// @match       https://poly23.dtemaharashtra.gov.in/diploma23/index.php/login_controller/*
// @grant       none
// @version     1.0
// @author      CoderOM
// @description 8/16/2023, 2:30:55 AM
// ==/UserScript==


(function() {
    'use strict';

    // Check if the captcha elements are present on the page
    var var1Input = document.getElementById('var1');
    var var2Input = document.getElementById('var2');
    var captchaInput = document.getElementById('captcha');

    if (var1Input && var2Input && captchaInput) {
        // Get the values of var1 and var2
        var var1 = parseInt(var1Input.value);
        var var2 = parseInt(var2Input.value);

        // Calculate the sum
        var sum = var1 + var2;

        // Set the sum as the value of the captcha input
        captchaInput.value = sum;
    }
})();
