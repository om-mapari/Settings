// ==UserScript==
// @name        New script - vmedulife.com
// @namespace   CoderOM
// @match       https://portal.vmedulife.com/student/StartFeedback.php
// @grant       none
// @version     1.0
// @author      CoderOM
// @description 3/24/2023, 8:38:41 PM
// ==/UserScript==
console.log("HELLO")

setInterval(()=>{
  if(document.getElementById('Progressbar').innerText !== '100%')
  {
    if(document.getElementById("seleted_answer_1"))
    {
      document.getElementById("seleted_answer_1").click()
    }
    if(document.getElementById('Progressbar').innerText !== '100%' && document.getElementById('btnNext')) {
      document.getElementById('btnNext').click()
    }
  }
},1000)
