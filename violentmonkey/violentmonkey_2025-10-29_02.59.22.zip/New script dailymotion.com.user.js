// ==UserScript==
// @name        New script dailymotion.com
// @namespace   CoderOM
// @match       https://www.dailymotion.com/video/x9841p0*
// @grant       none
// @version     1.0
// @author      CoderOM
// @description 12/24/2024, 8:25:19 AM
// ==/UserScript==



(function () {
    "use strict";
    let isHidden = false;

    console.log('script-loaded')

    document.addEventListener("keydown", function onEvent(e) {
        console.log("HIIIIIIIIIIIII")

    });
})();