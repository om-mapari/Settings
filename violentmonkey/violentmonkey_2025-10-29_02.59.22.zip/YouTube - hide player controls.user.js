// ==UserScript==
// @name         YouTube - hide player controls
// @namespace    http://www.xyz.net/
// @license      WTFPL; http://www.xyz.net/
// @version      0.2
// @description  Add shortcut in YouTube video player controls for hiding/showing controls. ( press g  to hide)
// @author       CoderOm
// @include      https://www.youtube.com/*
// ==/UserScript==


(function () {
    "use strict";
    let isHidden = false;

    document.addEventListener("keydown", function (e) {
        if (e.key.toLowerCase() === "g") {
            if (isHidden) {
                // Show elements
                toggleVisibilityByClass('ytp-chrome-top', 'visible');
                toggleVisibilityByClass('ytp-chrome-bottom', 'visible');
                toggleVisibilityByClass('ytp-gradient-bottom', 'visible');
                toggleVisibilityByClass('ytp-gradient-top', 'visible');
                toggleVisibilityByClass('ytp-overlay-top-left', 'visible');
                toggleVisibilityByClass('ytp-overlay-bottom-left', 'visible');
                toggleVisibilityByClass('ytp-overlay-bottom-right', 'visible');
                toggleVisibilityByClass('ytp-overlays-container', 'visible');
                toggleVisibilityByClass('branding-img-container', 'visible');
                toggleVisibilityByClass('ytPlayerOverlayVideoDetailsRendererHost', 'visible');
                toggleVisibilityByClass('ytp-overlay-top-right', 'visible');
                toggleVisibilityByClass('ytp-suggested-action', 'visible');
                isHidden = false;
            } else {
                // Hide elements
                toggleVisibilityByClass('ytp-chrome-top', 'hidden');
                toggleVisibilityByClass('ytp-chrome-bottom', 'hidden');
                toggleVisibilityByClass('ytp-gradient-bottom', 'hidden');
                toggleVisibilityByClass('ytp-gradient-top', 'hidden');
                toggleVisibilityByClass('ytp-overlay-top-left', 'hidden');
                toggleVisibilityByClass('ytp-overlay-bottom-left', 'hidden');
                toggleVisibilityByClass('ytp-overlay-bottom-right', 'hidden');
                toggleVisibilityByClass('ytp-overlays-container', 'hidden');
                toggleVisibilityByClass('branding-img-container', 'hidden');
                toggleVisibilityByClass('ytPlayerOverlayVideoDetailsRendererHost', 'hidden');
                toggleVisibilityByClass('ytp-overlay-top-right', 'hidden');
                toggleVisibilityByClass('ytp-suggested-action', 'hidden');
                isHidden = true;
            }
        }
    });

    // Function to toggle visibility by class name
    function toggleVisibilityByClass(className, visibility) {
        const elements = document.getElementsByClassName(className);
        if (elements.length > 0) {
            Array.from(elements).forEach((el) => {
                el.style.visibility = visibility;
                if (visibility === 'hidden') {
                    const children = el.querySelectorAll('*');
                    children.forEach((child) => {
                        child.style.visibility = 'hidden';
                    });
                } else {
                    const children = el.querySelectorAll('*');
                    children.forEach((child) => {
                        child.style.visibility = 'visible';
                    });
                }
            });
        }
    }
})();






// (function () {
//     "use strict";
//     let isHidden = false;
//     document.addEventListener("keydown", function onEvent(e) {
//         if (e.key.toLowerCase() === "g") {
//             if (isHidden) {
//                 // Show elements
//                 document.getElementsByClassName('ytp-chrome-top')[0].style.visibility = 'visible';
//                 if (document.getElementsByClassName('branding-img-container')[0]) {
//                     document.getElementsByClassName('branding-img-container')[0].style.visibility = 'visible';
//                 }
//                 document.getElementsByClassName('ytp-chrome-bottom')[0].style.visibility = 'visible';
//                 document.getElementsByClassName("ytp-gradient-bottom")[0].style.visibility = 'visible';
//                 document.getElementsByClassName("ytp-gradient-top")[0].style.visibility = 'visible';

//                 // Show ytp-overlay-top-left and its contents
//                 if (document.getElementsByClassName('ytp-overlay-top-left')[0]) {
//                     const overlayTopLeftChildren = document.querySelectorAll('.ytp-overlay-top-left *');
//                     document.getElementsByClassName('ytp-overlay-top-left')[0].style.visibility = 'visible';
//                     overlayTopLeftChildren.forEach((child) => {
//                         child.style.visibility = 'visible';
//                     });
//                 }

//                 // Show ytp-overlay-bottom-left and its contents
//                 if (document.getElementsByClassName('ytp-overlay-bottom-left')[0]) {
//                     const overlayBottomLeftChildren = document.querySelectorAll('.ytp-overlay-bottom-left *');
//                     document.getElementsByClassName('ytp-overlay-bottom-left')[0].style.visibility = 'visible';
//                     overlayBottomLeftChildren.forEach((child) => {
//                         child.style.visibility = 'visible';
//                     });
//                 }

//                 // Show ytp-overlay-bottom-right and its contents
//                 if (document.getElementsByClassName('ytp-overlay-bottom-right')[0]) {
//                     const overlayBottomRightChildren = document.querySelectorAll('.ytp-overlay-bottom-right *');
//                     document.getElementsByClassName('ytp-overlay-bottom-right')[0].style.visibility = 'visible';
//                     overlayBottomRightChildren.forEach((child) => {
//                         child.style.visibility = 'visible';
//                     });
//                 }

//                 isHidden = false;
//             } else {
//                 // Hide elements
//                 document.getElementsByClassName('ytp-chrome-top')[0].style.visibility = 'hidden';
//                 if (document.getElementsByClassName('branding-img-container')[0]) {
//                     document.getElementsByClassName('branding-img-container')[0].style.visibility = 'hidden';
//                 }
//                 document.getElementsByClassName('ytp-chrome-bottom')[0].style.visibility = 'hidden';
//                 document.getElementsByClassName("ytp-gradient-bottom")[0].style.visibility = 'hidden';
//                 document.getElementsByClassName("ytp-gradient-top")[0].style.visibility = 'hidden';

//                 // Hide ytp-overlay-top-left and its contents
//                 if (document.getElementsByClassName('ytp-overlay-top-left')[0]) {
//                     const overlayTopLeftChildren = document.querySelectorAll('.ytp-overlay-top-left *');
//                     document.getElementsByClassName('ytp-overlay-top-left')[0].style.visibility = 'hidden';
//                     overlayTopLeftChildren.forEach((child) => {
//                         child.style.visibility = 'hidden';
//                     });
//                 }

//                 // Hide ytp-overlay-bottom-left and its contents
//                 if (document.getElementsByClassName('ytp-overlay-bottom-left')[0]) {
//                     const overlayBottomLeftChildren = document.querySelectorAll('.ytp-overlay-bottom-left *');
//                     document.getElementsByClassName('ytp-overlay-bottom-left')[0].style.visibility = 'hidden';
//                     overlayBottomLeftChildren.forEach((child) => {
//                         child.style.visibility = 'hidden';
//                     });
//                 }

//                 // Hide ytp-overlay-bottom-right and its contents
//                 if (document.getElementsByClassName('ytp-overlay-bottom-right')[0]) {
//                     const overlayBottomRightChildren = document.querySelectorAll('.ytp-overlay-bottom-right *');
//                     document.getElementsByClassName('ytp-overlay-bottom-right')[0].style.visibility = 'hidden';
//                     overlayBottomRightChildren.forEach((child) => {
//                         child.style.visibility = 'hidden';
//                     });
//                 }

//                 isHidden = true;
//             }
//         }
//     });
// })();





// (function () {
//     "use strict";
//     let isHidden = false;
//     document.addEventListener("keydown", function onEvent(e) {
//         if (e.key.toLowerCase() === "g") {
//             if (isHidden) {
//                 // Show elements
//                 document.getElementsByClassName('ytp-chrome-top')[0].style.visibility = 'visible';
//                 if (document.getElementsByClassName('branding-img-container')[0]) {
//                     document.getElementsByClassName('branding-img-container')[0].style.visibility = 'visible';
//                 }
//                 document.getElementsByClassName('ytp-chrome-bottom')[0].style.visibility = 'visible';
//                 document.getElementsByClassName("ytp-gradient-bottom")[0].style.visibility = 'visible';
//                 document.getElementsByClassName("ytp-gradient-top")[0].style.visibility = 'visible';

//                 // Show ytp-overlay-bottom-left and its contents
//                 if (document.getElementsByClassName('ytp-overlay-bottom-left')[0]) {
//                     const overlayBottomLeftChildren = document.querySelectorAll('.ytp-overlay-bottom-left *');
//                     document.getElementsByClassName('ytp-overlay-bottom-left')[0].style.visibility = 'visible';
//                     overlayBottomLeftChildren.forEach((child) => {
//                         child.style.visibility = 'visible';
//                     });
//                 }

//                 // Show ytp-overlay-bottom-right and its contents
//                 if (document.getElementsByClassName('ytp-overlay-bottom-right')[0]) {
//                     const overlayBottomRightChildren = document.querySelectorAll('.ytp-overlay-bottom-right *');
//                     document.getElementsByClassName('ytp-overlay-bottom-right')[0].style.visibility = 'visible';
//                     overlayBottomRightChildren.forEach((child) => {
//                         child.style.visibility = 'visible';
//                     });
//                 }

//                 isHidden = false;
//             } else {
//                 // Hide elements
//                 document.getElementsByClassName('ytp-chrome-top')[0].style.visibility = 'hidden';
//                 if (document.getElementsByClassName('branding-img-container')[0]) {
//                     document.getElementsByClassName('branding-img-container')[0].style.visibility = 'hidden';
//                 }
//                 document.getElementsByClassName('ytp-chrome-bottom')[0].style.visibility = 'hidden';
//                 document.getElementsByClassName("ytp-gradient-bottom")[0].style.visibility = 'hidden';
//                 document.getElementsByClassName("ytp-gradient-top")[0].style.visibility = 'hidden';

//                 // Hide ytp-overlay-bottom-left and its contents
//                 if (document.getElementsByClassName('ytp-overlay-bottom-left')[0]) {
//                     const overlayBottomLeftChildren = document.querySelectorAll('.ytp-overlay-bottom-left *');
//                     document.getElementsByClassName('ytp-overlay-bottom-left')[0].style.visibility = 'hidden';
//                     overlayBottomLeftChildren.forEach((child) => {
//                         child.style.visibility = 'hidden';
//                     });
//                 }

//                 // Hide ytp-overlay-bottom-right and its contents
//                 if (document.getElementsByClassName('ytp-overlay-bottom-right')[0]) {
//                     const overlayBottomRightChildren = document.querySelectorAll('.ytp-overlay-bottom-right *');
//                     document.getElementsByClassName('ytp-overlay-bottom-right')[0].style.visibility = 'hidden';
//                     overlayBottomRightChildren.forEach((child) => {
//                         child.style.visibility = 'hidden';
//                     });
//                 }

//                 isHidden = true;
//             }
//         }
//     });
// })();
